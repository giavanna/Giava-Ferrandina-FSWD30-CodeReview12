<div class="item">

    <div class="layer-media">
        <div class="thumb "><img src="<?php echo post_grid_plugin_url; ?>assets/admin/images/thumb.png" /></div>
    </div>
    <div class="layer-content">
        <div class="title ">Hello title</div>
        <div class="content ">There are many variations of passages of Lorem Ipsum available, but the majority have</div>
    </div>

</div>