<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <body>
      <footer class="blog-footer">
          <p> &copy; <?php echo Date('Y'); ?> - Mount Everest - Kettenbrückengasse, 12 1050 Wien</p>
          <p>
            <a href="#">Back to top</a>
          </p>
        </footer>
        <?php wp_footer(); ?>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
      <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
  </body>
</html>