
<body>
      <?php get_header(); ?>
        <h1>Our Best Destinations for you</h1>
        <hr>

    <div class="row">
      <div class="col-sm-8 blog-main">
          <div class="row">
            <div class="col-sm-8 blog-main">
              <div class="blog-post">
              <?php echo do_shortcode("[post_grid id='120']"); ?>
              </div>
            </div>
          </div>
              <!--<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

                  <div class="blog-post">
                    <h2 class="blog-post-title">
                    <a href="<?php the_permalink(); // href to a specific blog post ?>">
                      <?php the_title(); // blog post title ?>
                    </a>
                  </h2>
                    <p class="blog-post-meta"><?php the_time('d.m.Y G:i'); // blog post date and time ?>
                    by <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')) ?>"> <?php the_author(); // blog post author ?> </a></p>

                  <?php if(has_post_thumbnail()) : ?>

                    <div class="post-thumb">
                      <?php the_post_thumbnail(); ?>
                    </div>
                  <?php endif; ?>

                    <p><?php the_excerpt(); // blog post content ?></p>
        
                    
                  </div> /.blog-post 
                  <?php endwhile; else:  ?>
                  <div class="blog-post">
                <h2 class="blog-post-title"><?php echo('No Posts Found'); ?></h2>
                 </div></.blog-post
                <?php endif; ?>-->
                  
            </div>
                   <!--/.blog-main-->

            <div class="col-sm-3 col-sm-offset-1 blog-sidebar">
    	          <div class="sidebar-module sidebar-module-inset">
    	          
    		       <section class="boxes">
    				     <div class="container">
    				       <div class="row">
    				         <div class="col-md-4">
    				           <div class="first-widget box" id="widgetbox">
    				             <i class="fa fa-paper-plane" aria-hidden="true"></i>
    				                 <?php
    				       			if(is_active_sidebar('first-widget')):
    				       				dynamic_sidebar('first-widget');
    				       			endif; ?>
    				           </div>
    				          </div>
    		        	 	</div>
    		       		 </div>
    	  		  </section>
    	  		</div>
      		</div>
        </div>


             
    <?php get_footer(); ?>
</body>
